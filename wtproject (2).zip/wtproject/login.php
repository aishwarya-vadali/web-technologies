<?php
// Database connection settings
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "root"; // Replace with your MySQL password
$dbname = "learnhub"; // Replace with your database name

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the submitted login credentials from the HTML form
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Query the database to retrieve the user's information
    $sql = "SELECT * FROM register WHERE user = '$username' AND passwod = '$password'";
    $result = $conn->query($sql);

    if (mysqli_num_rows($result) == 1) {
        // Login successful
        header("Location: home.html"); // Redirect to the dashboard page
        exit();
    } else {
        // Login failed
        echo "<script>alert('Invalid username or password'); window.location.href = 'login.html';</script>";
    }
}

// Close the database connection
$conn->close();
?>
