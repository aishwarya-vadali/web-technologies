<?php
// Database connection settings
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "root"; // Replace with your MySQL password
$dbname = "learnhub"; // Replace with your database name

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the submitted login credentials from the HTML form
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Password validation
    $containsUppercase = preg_match('/[A-Z]/', $password);
    $containsLowercase = preg_match('/[a-z]/', $password);
    $containsNumber = preg_match('/[0-9]/', $password);
    $containsSymbol = preg_match('/[!@#$%^&*]/', $password);
    $isLengthValid = strlen($password) >= 8;

    if ($containsUppercase && $containsLowercase && $containsNumber && $containsSymbol && $isLengthValid) {
        // Store the login information in the database
        $sql = "INSERT INTO register(user, passwod) VALUES ('$username', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo '<script>alert("Registered successfully!"); window.location.href = "login.html";</script>';
            exit(); // Added to stop executing the remaining code
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo '<script>alert("Password must include at least one uppercase letter, one lowercase letter, one number, one symbol, and be at least 8 characters long."); window.location.href = "registerdemo.html";</script>';
        exit(); // Added to stop executing the remaining code
    }
}

// Close the database connection
$conn->close();
?>
